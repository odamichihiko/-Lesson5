# class BooklistsController < ApplicationController
  
  # 新規作成--------------------------------------------------------------------
  # def new
   # Viewへ渡すためのインスタンス変数(@list)に空のモデルオブジェクト(List.new)を生成する。
  # @list = List.new
  # end
  
  # 入力------------------------------------------------------------------------
  # def create
   
    # @list = List.new(list_params)
    # if @list.save
      
      # flashというハッシュに :notice をいうキーで '投稿が完了しました！' という文字列の値を保存
      # flash[:notice] = '投稿が完了しました！'
    # redirect_to booklist_path(@list.id), notice: 'Book was successfully created'
    # else
      # render :new
    # end
    # 1. データを新規登録するためのインスタンス作成
     #list = List.new(list_params)
    # 2. データをデータベースに保存するためのsaveメソッド実行
     #list.save
    # 3. トップ画面へリダイレクト
     #redirect_to booklist_path(list.id)
  # end
  
  # 黙示------------------------------------------------------------------------
  # def index
    #複数のlistの表示をするから複数形になっている
    # @lists = List.all
  # end
  
  # 見る------------------------------------------------------------------------
  # def show          #      ↓      routes.rbの（/:id）URLを取得
    # @list = List.find(params[:id])
  # end
  
  # 編集------------------------------------------------------------------------
  # def edit
    # @list = List.find(params[:id])
  # end
  
  # 編集を保存------------------------------------------------------------------
  # def update
    # list = List.find(params[:id])
    # list.update(list_params)
    # redirect_to booklist_path(list.id)
  # end
  
  # 削除------------------------------------------------------------------------
  # def destroy
  # list = List.find(params[:id])  # データ（レコード）を1件取得
  # list.destroy  # データ（レコード）を削除
  # redirect_to booklists_path  # 投稿一覧画面へリダイレクト
  # end
  
  
  
  #ここから下はcontrollerの中でしか呼び出せません(重要：必ず一番下)
  # private
  #ストロングパラメータ（フォームの入力値をコントローラのcreateやupdateに渡す役割)
     #     ↓     の中にフォームで入力されたデータが格納
  # def list_params
   #paramsはRailsで送られてきた値を受け取るためのメソッド
   #requireでデータのオブジェクト名(ここでは:list)を指定し、
   #permitでキー（:title,:body）を指定しています。
   #もとはparams.require(:list).permit(:title, :body)
    # params.permit(:title, :body)
  # end
  
# end