class BooksController < ApplicationController

  def books
  end

  # 新規作成(ここではindexで投稿フォームを作っているためここにはない)--------------------------------------------------------------------
  # def new
   # Viewへ渡すためのインスタンス変数(@list)に空のモデルオブジェクト(List.new)を生成する。
  # @book = Book.new
  # end

  # 入力------------------------------------------------------------------------
  def create

    @book = Book.new(book_params)
    @books = Book.all
    if @book.save
      # flashというハッシュに :notice をいうキーで '投稿が完了しました！' という文字列の値を保存
      # flash[:notice] = '投稿が完了しました！'
      redirect_to booklist_path(@book.id), notice: 'Book was successfully created'
    else
      render :index
    end
    # 1. データを新規登録するためのインスタンス作成
     #list = List.new(list_params)
    # 2. データをデータベースに保存するためのsaveメソッド実行
     #list.save
    # 3. トップ画面へリダイレクト
     #redirect_to booklist_path(list.id)
  end

  # 黙示＋新規投稿------------------------------------------------------------------------
  def index
    # Viewへ渡すためのインスタンス変数(@list)に空のモデルオブジェクト(List.new)を生成する。
    @book = Book.new
    #複数のlistの表示をするから複数形になっている
    @books = Book.all
  end

  # 見る------------------------------------------------------------------------
  def show          #      ↓      routes.rbの（/:id）URLを取得
    @book = Book.find(params[:id])
  end

  # 編集------------------------------------------------------------------------
  def edit
    @book = Book.find(params[:id])

  end

  # 編集を保存------------------------------------------------------------------
  def update
    @book = Book.find(params[:id])
    @book.update(book_params)
    if @book.save
        redirect_to booklist_path(@book.id), notice: 'Book was successfully update'
    else
        render :edit
    end
  end

  # 削除------------------------------------------------------------------------
  def destroy
   book = Book.find(params[:id])  # データ（レコード）を1件取得
   book.destroy  # データ（レコード）を削除
   redirect_to books_path, notice: 'Book was successfully destroyed.' # 投稿一覧画面へリダイレクト,メッセージの表示
  end



  #ここから下はcontrollerの中でしか呼び出せません(重要：必ず一番下)
  private
  #ストロングパラメータ（フォームの入力値をコントローラのcreateやupdateに渡す役割)
     #     ↓     の中にフォームで入力されたデータが格納
  def book_params
   #paramsはRailsで送られてきた値を受け取るためのメソッド
   #requireでデータのオブジェクト名(ここでは:list)を指定し、
   #permitでキー（:title,:body）を指定しています。
   #もとはparams.require(:list).permit(:title, :body)
    params.require(:book).permit(:title, :body)
  end

end

