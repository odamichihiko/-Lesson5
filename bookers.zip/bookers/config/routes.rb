Rails.application.routes.draw do
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
  # ｛/books｝と書かれたら(bboksコントローラ)の(booksアクションを呼び出す)
   root to:'books#books'
   # get '/' => 'books#books'
   post 'books' => 'books#create'
   get 'books' => 'books#index'
   get 'books/:id' => 'books#show',as: 'booklist'
  # ルーティングのURLに:idと記述するとbooklists/◯◯/editのすべてのURLが対象になる
   get 'books/:id/edit' => 'books#edit', as: 'edit_booklist'
   patch 'books/:id' => 'books#update',as: 'update_booklist'
  # delete 'books/:id' => 'books#destroy', as: 'destroy_booklist'
  resources :books
end
